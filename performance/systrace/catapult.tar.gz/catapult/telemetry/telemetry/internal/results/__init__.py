# Copyright 2014 The Chromium Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.
"""
The PageTestResults hierarchy provides a way of representing the results of
running the test or measurement on pages.
"""

